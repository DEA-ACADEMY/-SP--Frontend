import { useEffect, useMemo, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { kyInstance } from "@/providers/data";
import { useTranslation } from "react-i18next";
import { useLanguage } from "@/components/refine-ui/language/language-provider";
import { cn } from "@/lib/utils";

type Branch = {
    id: string;
    name?: string | null;
};

type Program = {
    id: string;
    name?: string | null;
    branchId: string;
};

type Cohort = {
    id: string;
    name?: string | null;
    programId: string;
};

type Student = {
    id: string;
    name?: string | null;
    email?: string | null;
    cohortId?: string | null;
};

type Enrollment = {
    studentId: string;
    cohortId?: string | null;
};

function asArray<T>(value: unknown): T[] {
    return Array.isArray(value) ? value : (value as any)?.data ?? [];
}

export default function CohortsList() {
    const { t } = useTranslation();
    const { dir } = useLanguage();

    const [branches, setBranches] = useState<Branch[]>([]);
    const [programs, setPrograms] = useState<Program[]>([]);
    const [cohorts, setCohorts] = useState<Cohort[]>([]);
    const [students, setStudents] = useState<Student[]>([]);
    const [enrollments, setEnrollments] = useState<Enrollment[]>([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);

    async function load() {
        const [branchesJson, programsJson, cohortsJson, studentsJson, enrollmentsJson] = await Promise.all([
            kyInstance.get("branches", { searchParams: { _start: "0", _end: "1000" } }).json(),
            kyInstance.get("programs", { searchParams: { _start: "0", _end: "1000" } }).json(),
            kyInstance.get("cohorts", { searchParams: { _start: "0", _end: "1000" } }).json(),
            kyInstance.get("students", { searchParams: { _start: "0", _end: "1000" } }).json(),
            kyInstance.get("enrollments", { searchParams: { _start: "0", _end: "1000" } }).json(),
        ]);

        setBranches(asArray<Branch>(branchesJson));
        setPrograms(asArray<Program>(programsJson));
        setCohorts(asArray<Cohort>(cohortsJson));
        setStudents(asArray<Student>(studentsJson));
        setEnrollments(asArray<Enrollment>(enrollmentsJson));
    }

    useEffect(() => {
        let cancelled = false;

        async function run() {
            try {
                setLoading(true);
                setError(null);
                await load();
            } catch (e: any) {
                if (!cancelled) setError(e?.message ?? t("cohorts.messages.failedToLoad"));
            } finally {
                if (!cancelled) setLoading(false);
            }
        }

        void run();

        return () => {
            cancelled = true;
        };
    }, [t]);

    const branchName = useMemo(
        () => new Map(branches.map((branch) => [branch.id, branch.name ?? t("dashboard.report.unnamed.branch")])),
        [branches, t],
    );

    const cohortsByProgramId = useMemo(() => {
        const map = new Map<string, Cohort[]>();

        for (const cohort of cohorts) {
            map.set(cohort.programId, [...(map.get(cohort.programId) ?? []), cohort]);
        }

        return map;
    }, [cohorts]);

    const studentsByCohortId = useMemo(() => {
        const cohortByStudentId = new Map(
            enrollments
                .filter((enrollment) => enrollment.cohortId)
                .map((enrollment) => [enrollment.studentId, enrollment.cohortId as string]),
        );
        const map = new Map<string, Student[]>();

        for (const student of students) {
            const cohortId = student.cohortId ?? cohortByStudentId.get(student.id);
            if (!cohortId) continue;
            map.set(cohortId, [...(map.get(cohortId) ?? []), student]);
        }

        return map;
    }, [students, enrollments]);

    return (
        <div className={cn("w-full max-w-6xl space-y-6 p-4 md:p-6", dir === "rtl" ? "text-right" : "text-left")}>
            <div className={dir === "rtl" ? "text-right" : "text-left"}>
                <h1 className="text-2xl font-semibold">{t("cohorts.titles.list")}</h1>
                <p className="text-sm text-muted-foreground">{t("cohorts.messages.description")}</p>
            </div>

            {loading ? <div className="text-sm text-muted-foreground">{t("common.loading")}</div> : null}
            {error ? <div className="text-sm text-destructive">{error}</div> : null}

            {!loading && !error && programs.length === 0 ? (
                <div className="text-sm text-muted-foreground">{t("cohorts.messages.noPrograms")}</div>
            ) : null}

            <div className="space-y-5">
                {programs.map((program) => {
                    const programCohorts = [...(cohortsByProgramId.get(program.id) ?? [])].sort(
                        (a, b) => (a.name ?? "").localeCompare(b.name ?? ""),
                    );

                    return (
                        <Card key={program.id} className="overflow-hidden">
                            <CardHeader>
                                <div className={dir === "rtl" ? "text-right" : "text-left"}>
                                    <CardTitle>{program.name ?? t("dashboard.report.unnamed.program")}</CardTitle>
                                    <div className="text-sm text-muted-foreground">
                                        {branchName.get(program.branchId) ?? t("common.notAvailable")}
                                    </div>
                                </div>
                            </CardHeader>
                            <CardContent className="space-y-4">
                                {programCohorts.length === 0 ? (
                                    <div className="text-sm text-muted-foreground">{t("cohorts.messages.empty")}</div>
                                ) : (
                                    <div className="grid gap-4 lg:grid-cols-2">
                                        {programCohorts.map((cohort) => {
                                            const cohortStudents = studentsByCohortId.get(cohort.id) ?? [];

                                            return (
                                                <div key={cohort.id} className="rounded-lg border bg-muted/20 p-4">
                                                    <div className={cn("flex items-center justify-between gap-3", dir === "rtl" && "flex-row-reverse")}>
                                                        <div>
                                                            <div className="font-semibold">
                                                                {cohort.name ?? t("dashboard.report.unnamed.cohort")}
                                                            </div>
                                                            <div className="text-sm text-muted-foreground">
                                                                {t("cohorts.messages.studentCount", { count: cohortStudents.length })}
                                                            </div>
                                                        </div>
                                                    </div>

                                                    <div className="mt-4 space-y-2">
                                                        {cohortStudents.length === 0 ? (
                                                            <div className="rounded-md border border-dashed p-3 text-sm text-muted-foreground">
                                                                {t("cohorts.messages.noStudents")}
                                                            </div>
                                                        ) : (
                                                            cohortStudents.map((student) => (
                                                                <div
                                                                    key={student.id}
                                                                    className={cn(
                                                                        "flex items-center justify-between gap-3 rounded-md border bg-background p-3",
                                                                        dir === "rtl" && "flex-row-reverse",
                                                                    )}
                                                                >
                                                                    <div className="min-w-0">
                                                                        <div className="truncate font-medium">
                                                                            {student.name ?? t("dashboard.report.unnamed.student")}
                                                                        </div>
                                                                        {student.email ? (
                                                                            <div className="truncate text-sm text-muted-foreground">
                                                                                {student.email}
                                                                            </div>
                                                                        ) : null}
                                                                    </div>
                                                                </div>
                                                            ))
                                                        )}
                                                    </div>
                                                </div>
                                            );
                                        })}
                                    </div>
                                )}
                            </CardContent>
                        </Card>
                    );
                })}
            </div>
        </div>
    );
}
