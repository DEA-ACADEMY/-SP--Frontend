﻿import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Trophy } from "lucide-react";
import type { BadgeItem } from "./types.ts";
import { useLanguage } from "@/components/refine-ui/language/language-provider";
import { cn } from "@/lib/utils";
import { useTranslation } from "react-i18next";

export function BadgesCard({ items }: { items: BadgeItem[] }) {
    const { dir } = useLanguage();
    const { t } = useTranslation();

    return (
        <Card className="shadow-lg">
            <CardHeader className={cn("flex flex-row items-center justify-between gap-3 space-y-0", dir === "rtl" && "flex-row-reverse")}>
                <div className={dir === "rtl" ? "text-right" : "text-left"}>
                    <CardTitle className="text-2xl font-bold">{t("dashboard.badges.sectionTitle")}</CardTitle>
                    <p className="mt-2 text-sm text-muted-foreground">{t("dashboard.badges.sectionDescription")}</p>
                </div>

                <div className="rounded-full bg-primary/10 p-3 text-primary">
                    <Trophy className="h-6 w-6" />
                </div>
            </CardHeader>

            <CardContent>
                <div className="grid gap-4 sm:grid-cols-2">
                    {items.map((item) => {
                        const Icon = item.icon;

                        return (
                            <div
                                key={item.title}
                                className={cn(
                                    "rounded-3xl border bg-card p-6 shadow-sm transition-transform hover:-translate-y-0.5",
                                    dir === "rtl" ? "text-right" : "text-left",
                                )}
                            >
                                <div className="mb-4 inline-flex rounded-full bg-primary/10 p-4 text-primary">
                                    <Icon className="h-10 w-10" />
                                </div>

                                <div className="text-xl font-semibold">{item.title}</div>
                                <div className="mt-2 text-sm text-muted-foreground">{item.hint}</div>
                            </div>
                        );
                    })}
                </div>
            </CardContent>
        </Card>
    );
}
