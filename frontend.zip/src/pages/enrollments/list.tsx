import { useEffect, useState, type ReactNode } from "react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { authProvider } from "@/providers/auth";
import type { Role } from "@/lib/rbac";
import { useTranslation } from "react-i18next";
import { useLanguage } from "@/components/refine-ui/language/language-provider";
import { cn } from "@/lib/utils";
import { BookOpen, GitBranch, Layers3, UserPlus, UsersRound } from "lucide-react";

type EnrollmentAction = {
    title: string;
    description: string;
    href: string;
    icon: ReactNode;
    managementOnly?: boolean;
};

export default function EnrollmentsList() {
    const { t } = useTranslation();
    const { dir } = useLanguage();

    const [role, setRole] = useState<Role | null>(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);

    useEffect(() => {
        let cancelled = false;

        async function run() {
            try {
                setLoading(true);
                setError(null);

                const nextRole = (await authProvider.getPermissions?.()) as Role | null;

                if (!cancelled) {
                    setRole(nextRole ?? null);
                }
            } catch (e: any) {
                if (!cancelled) {
                    setError(e?.message ?? t("enrollments.messages.failedToLoad"));
                }
            } finally {
                if (!cancelled) setLoading(false);
            }
        }

        void run();

        return () => {
            cancelled = true;
        };
    }, [t]);

    const actions: EnrollmentAction[] = [
        {
            title: t("enrollments.actions.addStudent"),
            description: t("enrollments.messages.addStudentDescription"),
            href: "/students/create",
            icon: <UserPlus className="h-5 w-5" />,
        },
        {
            title: t("enrollments.actions.addProgram"),
            description: t("enrollments.messages.addProgramDescription"),
            href: "/programs/create",
            icon: <BookOpen className="h-5 w-5" />,
            managementOnly: true,
        },
        {
            title: t("enrollments.actions.manageBranches"),
            description: t("enrollments.messages.manageBranchesDescription"),
            href: "/branches",
            icon: <GitBranch className="h-5 w-5" />,
        },
        {
            title: t("enrollments.actions.reviewCohorts"),
            description: t("enrollments.messages.reviewCohortsDescription"),
            href: "/cohorts",
            icon: <Layers3 className="h-5 w-5" />,
        },
        {
            title: t("enrollments.actions.assignProgram"),
            description: t("enrollments.messages.assignProgramDescription"),
            href: "/students",
            icon: <UsersRound className="h-5 w-5" />,
        },
    ].filter((action) => !action.managementOnly || role === "management");

    return (
        <div className={cn("w-full max-w-6xl space-y-6 p-4 md:p-6", dir === "rtl" ? "text-right" : "text-left")}>
            <div className={cn("flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between", dir === "rtl" && "sm:flex-row-reverse")}>
                <div className={dir === "rtl" ? "text-right" : "text-left"}>
                    <h1 className="text-2xl font-semibold">{t("enrollments.titles.list")}</h1>
                    <p className="text-sm text-muted-foreground">{t("enrollments.messages.description")}</p>
                </div>
            </div>

            {loading ? <div className="text-sm text-muted-foreground">{t("common.loading")}</div> : null}
            {error ? <div className="text-sm text-destructive">{error}</div> : null}

            {!loading && !error ? (
                <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
                    {actions.map((action) => (
                        <Card key={action.href} className="overflow-hidden">
                            <CardHeader className={cn("flex flex-row items-start gap-3 space-y-0", dir === "rtl" && "flex-row-reverse")}>
                                <div className="rounded-md border bg-muted/40 p-2 text-primary">
                                    {action.icon}
                                </div>
                                <div className="min-w-0 flex-1">
                                    <CardTitle className="text-base">{action.title}</CardTitle>
                                    <p className="mt-1 text-sm text-muted-foreground">{action.description}</p>
                                </div>
                            </CardHeader>
                            <CardContent>
                                <Button asChild variant="outline" className="w-full">
                                    <Link to={action.href}>{t("common.open")}</Link>
                                </Button>
                            </CardContent>
                        </Card>
                    ))}
                </div>
            ) : null}
        </div>
    );
}
